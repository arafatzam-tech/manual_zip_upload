/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UploadedImage {
  id: string;
  name: string;
  file: File;
  src: string;
  size: number;
  width: number;
  height: number;
  aspectRatio: number;
  type: string;
  rotation?: number; // 0, 90, 180, 270 degrees
}

export type PageSize = 'A4' | 'LETTER' | 'A3' | 'A5' | 'AUTO';
export type Orientation = 'PORTRAIT' | 'LANDSCAPE' | 'AUTO';
export type MarginPreset = 'NONE' | 'THIN' | 'STANDARD' | 'THICK' | 'CUSTOM';
export type ScalingMode = 'FIT' | 'FILL' | 'ORIGINAL';

export interface PdfSettings {
  pageSize: PageSize;
  orientation: Orientation;
  scaling: ScalingMode;
  marginPreset: MarginPreset;
  customMargin: number; // in mm
  filename: string;
  author: string;
  title: string;
  subject: string;
  showPageNumbers: boolean;
  pageNumberPosition: 'left' | 'center' | 'right';
  customHeader: string;
  imageQuality: number; // 0.1 - 1.0
  backgroundColor: string; // Hex color code
}

export const PAGE_DIMENSIONS_MM: Record<Exclude<PageSize, 'AUTO'>, { width: number; height: number }> = {
  A4: { width: 210, height: 297 },
  LETTER: { width: 215.9, height: 279.4 },
  A3: { width: 297, height: 420 },
  A5: { width: 148, height: 210 },
};

export const MARGINS_MM: Record<Exclude<MarginPreset, 'CUSTOM'>, number> = {
  NONE: 0,
  THIN: 5,
  STANDARD: 10,
  THICK: 20,
};
