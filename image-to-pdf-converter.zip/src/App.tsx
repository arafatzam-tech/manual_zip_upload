/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  FileUp, FileSpreadsheet, FileText, Download, CheckCircle, RefreshCw, 
  Settings, Eye, Compass, Info, Github, Sparkles, Image as ImageIcon,
  BookOpen, Layers, ShieldCheck, Heart
} from 'lucide-react';
import UploadZone from './components/UploadZone';
import PDFSettings from './components/PDFSettings';
import PDFPageList from './components/PDFPageList';
import PDFPreview from './components/PDFPreview';
import { UploadedImage, PdfSettings } from './types';
import { generatePdf, GenerationProgress } from './utils/pdfGenerator';

const DEFAULT_SETTINGS: PdfSettings = {
  pageSize: 'A4',
  orientation: 'AUTO',
  scaling: 'FIT',
  marginPreset: 'STANDARD',
  customMargin: 10,
  filename: 'converted_images',
  author: '',
  title: '',
  subject: '',
  showPageNumbers: true,
  pageNumberPosition: 'center',
  customHeader: '',
  imageQuality: 0.85,
  backgroundColor: '#ffffff',
};

export default function App() {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [settings, setSettings] = useState<PdfSettings>(DEFAULT_SETTINGS);
  
  // Compilation states
  const [isCompiling, setIsCompiling] = useState(false);
  const [progress, setProgress] = useState<GenerationProgress | null>(null);
  const [compiledPdf, setCompiledPdf] = useState<{ url: string; filename: string; size: number } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showEmbedViewer, setShowEmbedViewer] = useState(false);

  // Auto clean URLs to prevent memory leaks when page is closed/refreshed
  useEffect(() => {
    return () => {
      images.forEach((img) => URL.revokeObjectURL(img.src));
      if (compiledPdf) {
        URL.revokeObjectURL(compiledPdf.url);
      }
    };
  }, []);

  // Update filename automatically based on first uploaded file as a helpful helper
  useEffect(() => {
    if (images.length > 0 && settings.filename === 'converted_images') {
      const firstImageName = images[0].name.replace(/\.[^/.]+$/, ""); // Strip extension
      const safeFilename = firstImageName.replace(/[^a-zA-Z0-9-_ ]/g, "").trim();
      setSettings(prev => ({
        ...prev,
        filename: `${safeFilename}_compiled`
      }));
    }
  }, [images]);

  const handleImagesAdded = (newImages: UploadedImage[]) => {
    setImages((prev) => [...prev, ...newImages]);
    setErrorMsg(null);
    setCompiledPdf(null); // Clear previous compilation since resources changed
  };

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    setImages((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index - 1];
      updated[index - 1] = temp;
      return updated;
    });
    setCompiledPdf(null);
  };

  const handleMoveDown = (index: number) => {
    if (index === images.length - 1) return;
    setImages((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index + 1];
      updated[index + 1] = temp;
      return updated;
    });
    setCompiledPdf(null);
  };

  const handleRemoveImage = (id: string) => {
    setImages((prev) => {
      const target = prev.find((img) => img.id === id);
      if (target) {
        URL.revokeObjectURL(target.src); // Release browser resource pointer
      }
      return prev.filter((img) => img.id !== id);
    });
    setCompiledPdf(null);
  };

  const handleRotateImage = (id: string) => {
    setImages((prev) =>
      prev.map((img) => {
        if (img.id === id) {
          const nextRotation = ((img.rotation || 0) + 90) % 360;
          return {
            ...img,
            rotation: nextRotation,
          };
        }
        return img;
      })
    );
    setCompiledPdf(null);
  };

  const handleClearAll = () => {
    images.forEach((img) => URL.revokeObjectURL(img.src));
    setImages([]);
    setCompiledPdf(null);
    setErrorMsg(null);
  };

  const handleSort = (type: 'name-asc' | 'name-desc' | 'size-asc' | 'size-desc') => {
    setImages((prev) => {
      const sorted = [...prev].sort((a, b) => {
        if (type === 'name-asc') {
          return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
        }
        if (type === 'name-desc') {
          return b.name.localeCompare(a.name, undefined, { numeric: true, sensitivity: 'base' });
        }
        if (type === 'size-asc') {
          return a.size - b.size;
        }
        if (type === 'size-desc') {
          return b.size - a.size;
        }
        return 0;
      });
      return sorted;
    });
    setCompiledPdf(null);
  };

  const triggerCompilation = async () => {
    if (images.length === 0) return;
    setIsCompiling(true);
    setErrorMsg(null);
    setCompiledPdf(null);

    try {
      const result = await generatePdf(images, settings, (update) => {
        setProgress(update);
      });

      setCompiledPdf({
        url: result.url,
        filename: result.filename,
        size: result.blob.size,
      });
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Verification of PDF assets failed during rendering.');
    } finally {
      setIsCompiling(false);
      setProgress(null);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div className="min-h-screen bg-[#0c0c14] text-white flex flex-col relative overflow-x-hidden font-sans antialiased selection:bg-indigo-500/30 selection:text-white">
      {/* Ambient Orb Backdrops */}
      <div className="absolute top-[-150px] left-[-150px] w-[500px] h-[500px] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[100px] right-[-100px] w-[600px] h-[600px] bg-fuchsia-600/10 rounded-full blur-[150px] pointer-events-none z-0"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none z-0"></div>

      {/* Visual Navigation Header */}
      <header className="sticky top-0 z-40 border-b border-white/10 backdrop-blur-xl bg-[#0c0c14]/45 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 rounded-2xl text-white shadow-lg flex items-center justify-center shadow-indigo-600/30">
              <FileSpreadsheet className="w-5.5 h-5.5 text-white stroke-[2]" />
            </div>
            <div>
              <h1 className="text-base font-bold font-sans tracking-tight text-white flex items-center gap-1.5">
                Image to PDF Converter
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-indigo-500/10 text-indigo-300 font-semibold rounded-full border border-indigo-500/20">
                  Client-side Engine
                </span>
              </h1>
              <p className="text-[11px] text-white/50 font-sans">
                Convert your photos, receipts, or screenshots into pristine, search-optimized PDF books.
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-6">
            <div className="text-right">
              <p className="text-[10px] text-white/30 font-sans uppercase">Security Standard</p>
              <p className="text-xs font-semibold text-white/80 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                100% In-Browser Privacy
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Primary Workspace */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT PANEL CONTENTS: Upload, Sorting Lists */}
          <section className="lg:col-span-7 space-y-6">
            
            {/* Custom description banner if list is empty */}
            {images.length === 0 && (
              <div className="backdrop-blur-xl bg-white/5 border border-white/10 text-white rounded-3xl p-6 relative overflow-hidden shadow-lg">
                <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 opacity-5 pointer-events-none">
                  <FileText className="w-64 h-64 text-indigo-400" />
                </div>
                <div className="max-w-md relative z-10">
                  <span className="inline-flex items-center gap-1 text-[10px] uppercase font-mono bg-indigo-500/10 text-indigo-300 px-2.5 py-1 rounded-full font-bold tracking-wider mb-3 border border-indigo-400/20">
                    <Sparkles className="w-3 h-3 text-indigo-300 animate-pulse" /> Instant Compilation
                  </span>
                  <h2 className="text-xl font-bold font-sans tracking-tight text-white mb-2">
                    Transform your pictures to vector PDF files in seconds
                  </h2>
                  <p className="text-xs text-white/60 leading-relaxed font-sans">
                    Drop images below. All pre-rendering is computed on your computer CPU. Your files never go to any cloud server, assuring complete confidentiality.
                  </p>
                </div>
              </div>
            )}

            {/* Direct Uploader */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-2xl">
              <UploadZone onImagesAdded={handleImagesAdded} />
            </div>

            {/* Configured Pages List representation */}
            <PDFPageList
              images={images}
              onMoveUp={handleMoveUp}
              onMoveDown={handleMoveDown}
              onRemove={handleRemoveImage}
              onRotate={handleRotateImage}
              onClearAll={handleClearAll}
              onSort={handleSort}
            />
          </section>

          {/* RIGHT PANEL CONTENTS: Config sliders, Preview list and download cards */}
          <section className="lg:col-span-5 space-y-6">
            
            {/* PDF Trigger and Export Card */}
            <div className="backdrop-blur-xl bg-indigo-950/40 text-white rounded-3xl p-5 shadow-2xl border border-indigo-500/25 relative overflow-hidden flex flex-col justify-between">
              
              <div className="relative z-10">
                <h3 className="text-xs font-bold font-sans uppercase tracking-wider text-indigo-300 mb-1">
                  Export Action Panel
                </h3>
                <p className="text-[11px] text-white/60 font-sans leading-relaxed">
                  Apply chosen layout preferences and combine active pages to format the PDF book.
                </p>
              </div>

              {/* Progress feedback for rendering */}
              {isCompiling && (
                <div className="mt-4 p-4 bg-indigo-950/60 rounded-2xl border border-indigo-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium font-sans text-indigo-200">
                      {progress?.message || 'Processing page grids...'}
                    </span>
                    <span className="text-xs font-mono font-bold text-indigo-300 animate-pulse">
                      {progress ? `${Math.round((progress.current / progress.total) * 100)}%` : 'Rendering'}
                    </span>
                  </div>
                  {/* Visual Bar progress */}
                  <div className="w-full bg-[#0c0c14]/50 rounded-full h-2 overflow-hidden border border-white/10">
                    <div 
                      className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                      style={{ 
                        width: progress ? `${(progress.current / progress.total) * 100}%` : '5%' 
                      }} 
                    />
                  </div>
                </div>
              )}

              {/* Success Result Container */}
              {compiledPdf && (
                <div className="mt-4 bg-emerald-500/10 rounded-2xl p-4 border border-emerald-500/25 animate-fadeIn space-y-3">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5 animate-pulse" />
                    <div>
                      <h4 className="text-xs font-bold text-white font-sans truncate">
                        {compiledPdf.filename}
                      </h4>
                      <p className="text-[10px] text-emerald-300 font-mono mt-0.5">
                        Size: {formatFileSize(compiledPdf.size)} • {images.length} Pages
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    {/* Primary Direct Download Button */}
                    <a
                      href={compiledPdf.url}
                      download={compiledPdf.filename}
                      className="flex-1 py-2.5 px-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold text-center flex items-center justify-center gap-1.5 transition-all shadow-lg shrink-0 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download PDF Document
                    </a>

                    {/* Toggle View button */}
                    <button
                      type="button"
                      onClick={() => setShowEmbedViewer(!showEmbedViewer)}
                      className="py-2.5 px-3 border border-white/10 hover:bg-white/10 rounded-xl text-xs font-semibold text-white text-center transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>{showEmbedViewer ? 'Hide Viewer' : 'Test Preview'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Errored Result Banner */}
              {errorMsg && (
                <div className="mt-4 bg-rose-950/80 border border-rose-850 text-rose-350 rounded-xl p-3 text-xs font-sans">
                  <strong>Error:</strong> {errorMsg}
                </div>
              )}

              {/* Direct compiler trigger button if not active */}
              {!isCompiling && (
                <button
                  type="button"
                  disabled={images.length === 0}
                  onClick={triggerCompilation}
                  className={`w-full py-3 px-4 rounded-2xl font-bold font-sans text-xs transition-all shadow-lg mt-4 flex items-center justify-center gap-2 tracking-wide cursor-pointer ${
                    images.length > 0
                      ? 'bg-indigo-600 text-white hover:bg-indigo-500 hover:scale-[1.01] active:scale-[0.99] shadow-indigo-600/25'
                      : 'bg-indigo-950/20 text-indigo-400/30 border border-indigo-900/50 cursor-not-allowed'
                  }`}
                >
                  {compiledPdf ? (
                    <>
                      <RefreshCw className="w-4 h-4 text-white animate-spin" style={{ animationDuration: '3s' }} />
                      Recompile PDF Document
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-white animate-pulse" />
                      Build and Export PDF Book
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Embedded browser verification viewport */}
            {compiledPdf && showEmbedViewer && (
              <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-3 shadow-xl animate-fadeIn space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-white/50 font-sans uppercase">
                    Compiled Binary Viewport
                  </span>
                  <button
                    onClick={() => setShowEmbedViewer(false)}
                    className="text-[10px] text-indigo-400 hover:text-indigo-300 font-mono font-semibold cursor-pointer"
                  >
                    CLOSE VIEWER
                  </button>
                </div>
                <iframe
                  src={compiledPdf.url}
                  className="w-full h-96 rounded-2xl border border-white/10 bg-[#0c0c14]/50"
                  title="PDF Compile Viewer"
                />
              </div>
            )}

            {/* Tailored Config selectors panel */}
            <PDFSettings
              settings={settings}
              onChange={setSettings}
              totalImages={images.length}
            />

            {/* Simulated Sheet visuals representation */}
            <PDFPreview
              images={images}
              settings={settings}
            />

          </section>

        </div>
      </main>

      {/* Decorative Brand Footer */}
      <footer className="border-t border-white/10 mt-20 py-8 px-6 text-center select-none bg-black/20">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-medium text-white/80 text-xs tracking-tight">
              Image to PDF Converter
            </span>
            <span className="text-[9px] font-sans text-white/40">
              v1.1.0 • Client Compiled
            </span>
          </div>
          <p className="text-[11px] text-white/40 font-sans flex items-center justify-center gap-1">
            Made with <Heart className="w-3 h-3 text-rose-500 fill-rose-500 animate-pulse" /> for fast browser operations.
          </p>
        </div>
      </footer>
    </div>
  );
}
