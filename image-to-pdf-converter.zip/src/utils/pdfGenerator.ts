/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { UploadedImage, PdfSettings, PAGE_DIMENSIONS_MM, MARGINS_MM } from '../types';

/**
 * Preprocess image via canvas to solve transparency issues and adjust compression quality.
 */
export function preprocessImage(
  imgSrc: string,
  quality: number,
  backgroundColor: string,
  rotation: number = 0
): Promise<{ dataUrl: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const normalizedRotation = ((rotation % 360) + 360) % 360;
      const isSwapped = normalizedRotation === 90 || normalizedRotation === 270;
      
      canvas.width = isSwapped ? img.naturalHeight : img.naturalWidth;
      canvas.height = isSwapped ? img.naturalWidth : img.naturalHeight;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not obtain canvas 2D context'));
        return;
      }

      // Draw background (prevents black overlay on transparent PNGs)
      ctx.fillStyle = backgroundColor || '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Apply rotation if needed
      if (normalizedRotation !== 0) {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((normalizedRotation * Math.PI) / 180);
        ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
      } else {
        ctx.drawImage(img, 0, 0);
      }

      try {
        // Output as JPEG URL with specified compression quality
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve({
          dataUrl,
          width: canvas.width,
          height: canvas.height,
        });
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = () => {
      reject(new Error('Failed to load image into processing engine'));
    };
    img.src = imgSrc;
  });
}

export interface GenerationProgress {
  status: 'starting' | 'processing' | 'assembling' | 'metadata' | 'completed' | 'error';
  total: number;
  current: number;
  message: string;
}

/**
 * Generates the tailored PDF.
 */
export async function generatePdf(
  images: UploadedImage[],
  settings: PdfSettings,
  onProgress?: (progress: GenerationProgress) => void
): Promise<{ blob: Blob; url: string; filename: string }> {
  if (images.length === 0) {
    throw new Error('No images selected for PDF generation.');
  }

  onProgress?.({
    status: 'starting',
    total: images.length,
    current: 0,
    message: 'Initializing compiler...',
  });

  // Pre-process and generate all page image definitions
  const processedImages: { dataUrl: string; width: number; height: number; aspectRatio: number }[] = [];

  for (let i = 0; i < images.length; i++) {
    onProgress?.({
      status: 'processing',
      total: images.length,
      current: i + 1,
      message: `Analyzing and scaling image ${i + 1} of ${images.length}...`,
    });

    try {
      const result = await preprocessImage(
        images[i].src,
        settings.imageQuality,
        settings.backgroundColor,
        images[i].rotation || 0
      );
      processedImages.push({
        dataUrl: result.dataUrl,
        width: result.width,
        height: result.height,
        aspectRatio: result.width / result.height,
      });
    } catch (err) {
      console.error(`Error processing image ${images[i].name}:`, err);
      // Fallback to original src if preprocessing fails
      processedImages.push({
        dataUrl: images[i].src,
        width: images[i].width || 800,
        height: images[i].height || 600,
        aspectRatio: images[i].aspectRatio || 1.33,
      });
    }
  }

  onProgress?.({
    status: 'assembling',
    total: images.length,
    current: 0,
    message: 'Assembling layout pages...',
  });

  // Create jsPDF instance
  // First page setup
  const originalImage = processedImages[0];
  let initialWidth = 210;
  let initialHeight = 297;
  let orient: 'p' | 'l' = 'p';

  if (settings.pageSize === 'AUTO') {
    initialWidth = originalImage.width * 0.264583;
    initialHeight = originalImage.height * 0.264583;
    if (settings.orientation === 'PORTRAIT' && initialWidth > initialHeight) {
      const temp = initialWidth;
      initialWidth = initialHeight;
      initialHeight = temp;
    } else if (settings.orientation === 'LANDSCAPE' && initialHeight > initialWidth) {
      const temp = initialWidth;
      initialWidth = initialHeight;
      initialHeight = temp;
    }
  } else {
    const dims = PAGE_DIMENSIONS_MM[settings.pageSize];
    const isLandscape =
      settings.orientation === 'LANDSCAPE' ||
      (settings.orientation === 'AUTO' && originalImage.aspectRatio > 1);
    initialWidth = isLandscape ? dims.height : dims.width;
    initialHeight = isLandscape ? dims.width : dims.height;
  }

  orient = initialWidth > initialHeight ? 'l' : 'p';

  const doc = new jsPDF({
    orientation: orient,
    unit: 'mm',
    format: settings.pageSize === 'AUTO' ? [initialWidth, initialHeight] : settings.pageSize.toLowerCase(),
  });

  // Configure first page background color
  doc.setFillColor(settings.backgroundColor);
  doc.rect(0, 0, initialWidth, initialHeight, 'F');

  // Draw first page content
  addSinglePageContent(doc, processedImages[0], settings, initialWidth, initialHeight, 1);

  // Remaining pages
  for (let j = 1; j < processedImages.length; j++) {
    const currentImg = processedImages[j];
    let pageWidth = 210;
    let pageHeight = 297;

    if (settings.pageSize === 'AUTO') {
      pageWidth = currentImg.width * 0.264583;
      pageHeight = currentImg.height * 0.264583;
      if (settings.orientation === 'PORTRAIT' && pageWidth > pageHeight) {
        const temp = pageWidth;
        pageWidth = pageHeight;
        pageHeight = temp;
      } else if (settings.orientation === 'LANDSCAPE' && pageHeight > pageWidth) {
        const temp = pageWidth;
        pageWidth = pageHeight;
        pageHeight = temp;
      }
    } else {
      const dims = PAGE_DIMENSIONS_MM[settings.pageSize];
      const isLandscape =
        settings.orientation === 'LANDSCAPE' ||
        (settings.orientation === 'AUTO' && currentImg.aspectRatio > 1);
      pageWidth = isLandscape ? dims.height : dims.width;
      pageHeight = isLandscape ? dims.width : dims.height;
    }

    const currentOrient = pageWidth > pageHeight ? 'l' : 'p';

    doc.addPage(
      settings.pageSize === 'AUTO' ? [pageWidth, pageHeight] : settings.pageSize.toLowerCase(),
      currentOrient
    );

    // Apply color to background
    doc.setFillColor(settings.backgroundColor);
    doc.rect(0, 0, pageWidth, pageHeight, 'F');

    addSinglePageContent(doc, currentImg, settings, pageWidth, pageHeight, j + 1);
  }

  // Draw Header / Footer overlays on all appropriate pages
  onProgress?.({
    status: 'metadata',
    total: images.length,
    current: images.length,
    message: 'Overlaying page numbering & metadata indexing...',
  });

  const totalPages = doc.getNumberOfPages();
  const marginVal = settings.marginPreset === 'CUSTOM' ? settings.customMargin : MARGINS_MM[settings.marginPreset];

  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    doc.setPage(pageNum);
    const pW = doc.internal.pageSize.width;
    const pH = doc.internal.pageSize.height;

    // Header Overlay (Only apply if header defined AND margin is present to avoid overlaying full bleed images)
    if (settings.customHeader && marginVal > 5) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139); // Tailwind Slate 500
      doc.text(settings.customHeader, marginVal, marginVal / 2 + 1, { align: 'left' });

      // Fine header hairline
      doc.setDrawColor(226, 232, 240); // Slate 200
      doc.setLineWidth(0.15);
      doc.line(marginVal, marginVal / 2 + 3, pW - marginVal, marginVal / 2 + 3);
    }

    // Page Numbers (Avoid overlaying on full bleed margins unless explicitly configured)
    if (settings.showPageNumbers && (marginVal > 4 || settings.pageSize === 'AUTO')) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // Slate 400
      const numeral = `Page ${pageNum} of ${totalPages}`;

      let xPos = pW / 2;
      let alignPos: 'center' | 'left' | 'right' = 'center';

      if (settings.pageNumberPosition === 'left') {
        xPos = Math.max(8, marginVal);
        alignPos = 'left';
      } else if (settings.pageNumberPosition === 'right') {
        xPos = pW - Math.max(8, marginVal);
        alignPos = 'right';
      } else {
        xPos = pW / 2;
        alignPos = 'center';
      }

      // If margin size is very thin, put numbers safely 5mm from bottom
      const yOffset = marginVal > 0 ? (marginVal / 2 + 1) : 5;
      doc.text(numeral, xPos, pH - yOffset, { align: alignPos });
    }
  }

  // Set Search Metainfo
  doc.setProperties({
    title: settings.title || 'Converted Images PDF',
    subject: settings.subject || 'Generated from Image to PDF Converter App',
    author: settings.author || 'Image to PDF Engine',
    creator: 'Image to PDF Premium Web Application',
    keywords: 'PDF, Image Converter, Scan, Document',
  });

  onProgress?.({
    status: 'completed',
    total: images.length,
    current: images.length,
    message: 'Finished! Preparing download...',
  });

  // Output blob
  const pdfBlob = doc.output('blob');
  const blobUrl = URL.createObjectURL(pdfBlob);

  // Clean extension
  let safeFilename = settings.filename.trim() || 'converted_images';
  if (!safeFilename.toLowerCase().endsWith('.pdf')) {
    safeFilename += '.pdf';
  }

  return {
    blob: pdfBlob,
    url: blobUrl,
    filename: safeFilename,
  };
}

/**
 * Positions and prints a single image onto a PDF page layout
 */
function addSinglePageContent(
  doc: jsPDF,
  image: { dataUrl: string; width: number; height: number; aspectRatio: number },
  settings: PdfSettings,
  pageWidth: number,
  pageHeight: number,
  pageIndex: number
) {
  const margin = settings.marginPreset === 'CUSTOM' ? settings.customMargin : MARGINS_MM[settings.marginPreset];

  // If margin preset is too large for the page, clip it safely
  const printableWidth = Math.max(10, pageWidth - 2 * margin);
  const printableHeight = Math.max(10, pageHeight - 2 * margin);

  let targetW = printableWidth;
  let targetH = printableHeight;
  let xPos = margin;
  let yPos = margin;

  if (settings.scaling === 'FIT') {
    // scale to fit inside printable bounding box
    const scaleX = printableWidth / image.width;
    const scaleY = printableHeight / image.height;
    const scale = Math.min(scaleX, scaleY);

    targetW = image.width * scale;
    targetH = image.height * scale;

    // Center in printable container
    xPos = margin + (printableWidth - targetW) / 2;
    yPos = margin + (printableHeight - targetH) / 2;

  } else if (settings.scaling === 'ORIGINAL') {
    // 0.264583 is the mm per pixel size at 96 DPI
    const originalW = image.width * 0.264583;
    const originalH = image.height * 0.264583;

    targetW = originalW;
    targetH = originalH;

    // Scale down only if image is larger than printable container
    if (targetW > printableWidth || targetH > printableHeight) {
      const scaleX = printableWidth / targetW;
      const scaleY = printableHeight / targetH;
      const scale = Math.min(scaleX, scaleY);

      targetW *= scale;
      targetH *= scale;
    }

    // Center in printable coordinates
    xPos = margin + (printableWidth - targetW) / 2;
    yPos = margin + (printableHeight - targetH) / 2;

  } else {
    // 'FILL' -> stretch/fill image fully to the printable bounding box bounds
    targetW = printableWidth;
    targetH = printableHeight;
    xPos = margin;
    yPos = margin;
  }

  // Draw image
  doc.addImage(
    image.dataUrl,
    'JPEG',
    xPos,
    yPos,
    targetW,
    targetH,
    `img_${pageIndex}`,
    'FAST'
  );
}
