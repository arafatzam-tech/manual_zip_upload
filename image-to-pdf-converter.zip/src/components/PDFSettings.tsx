/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PdfSettings, PageSize, Orientation, MarginPreset, ScalingMode } from '../types';
import { 
  FileText, Settings, AlignJustify, Eye, Sliders, Palette, Info, LayoutTemplate, 
  BookOpen, Hash, AlignCenter, User
} from 'lucide-react';

interface PDFSettingsProps {
  settings: PdfSettings;
  onChange: (updated: PdfSettings) => void;
  totalImages: number;
}

export default function PDFSettings({ settings, onChange, totalImages }: PDFSettingsProps) {
  const updateSetting = <K extends keyof PdfSettings>(key: K, value: PdfSettings[K]) => {
    onChange({
      ...settings,
      [key]: value
    });
  };

  const pagePresetLabels: Record<PageSize, string> = {
    A4: 'A4 Standard (210 × 297 mm)',
    LETTER: 'US Letter (215.9 × 279.4 mm)',
    A3: 'A3 High-Res (297 × 420 mm)',
    A5: 'A5 Flyer (148 × 210 mm)',
    AUTO: 'Auto-Fit (Matches each image dimension)'
  };

  const bgColorsPreset = [
    { name: 'White', value: '#ffffff', class: 'bg-white border-white/20' },
    { name: 'Paper White', value: '#fafaf9', class: 'bg-stone-50 border-white/20' },
    { name: 'Midnight', value: '#0f172a', class: 'bg-slate-900 border-white/10' },
    { name: 'Slate Light', value: '#f1f5f9', class: 'bg-slate-150 border-white/20' },
    { name: 'Warm Warmth', value: '#fafaf0', class: 'bg-yellow-50/55 border-white/20' },
  ];

  return (
    <div className="backdrop-blur-xl bg-white/5 rounded-3xl border border-white/10 shadow-2xl divide-y divide-white/5 select-none text-white overflow-hidden">
      {/* Title block */}
      <div className="p-4 bg-white/3 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-2">
          <Settings className="w-4 h-4 text-indigo-400" />
          <h2 className="text-sm font-semibold text-white font-sans tracking-tight">PDF Configuration</h2>
        </div>
        <span className="text-[11px] bg-indigo-500/10 border border-indigo-400/20 text-indigo-300 px-2.5 py-0.5 rounded-full font-mono text-right font-medium">
          {totalImages} image{totalImages !== 1 ? 's' : ''} loaded
        </span>
      </div>

      {/* Basic Settings */}
      <div className="p-4 space-y-4">
        {/* Filename */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-indigo-400" /> Output File Name
          </label>
          <div className="relative rounded-xl shadow-inner">
            <input
              type="text"
              value={settings.filename}
              onChange={(e) => updateSetting('filename', e.target.value)}
              placeholder="e.g. converted-images"
              className="w-full text-xs font-sans border border-white/10 rounded-xl px-3 py-2.5 bg-white/5 hover:bg-white/10 hover:border-white/20 focus:bg-white/10 focus:border-indigo-500 focus:outline-hidden transition-all text-white placeholder-white/30"
            />
            <div className="absolute right-3 top-2.5 text-[11px] text-white/30 font-mono pointer-events-none select-none">
              .pdf
            </div>
          </div>
        </div>

        {/* Page Sizing Presets */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <LayoutTemplate className="w-3.5 h-3.5 text-indigo-400" /> Page Dimensions
          </label>
          <select
            value={settings.pageSize}
            onChange={(e) => updateSetting('pageSize', e.target.value as PageSize)}
            className="w-full text-xs font-sans border border-white/10 rounded-xl p-2.5 bg-white/5 hover:bg-white/10 hover:border-white/20 focus:bg-[#0c0c14] focus:border-indigo-500 focus:outline-hidden transition-all text-white [&>option]:bg-[#0c0c14] [&>option]:text-white"
          >
            {Object.keys(pagePresetLabels).map((size) => (
              <option key={size} value={size}>
                {pagePresetLabels[size as PageSize]}
              </option>
            ))}
          </select>
        </div>

        {/* Orientation Override */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" /> Page Orientation
          </label>
          <div className="grid grid-cols-3 gap-1 p-0.5 bg-white/5 rounded-xl border border-white/10">
            {(['AUTO', 'PORTRAIT', 'LANDSCAPE'] as Orientation[]).map((orient) => (
              <button
                key={orient}
                type="button"
                onClick={() => updateSetting('orientation', orient)}
                className={`py-1.5 rounded-lg text-[11px] font-medium font-sans text-center transition-all ${
                  settings.orientation === orient
                    ? 'bg-indigo-650 shadow-md text-white font-semibold'
                    : 'text-white/40 hover:text-white/80'
                }`}
              >
                {orient === 'AUTO' ? 'Auto' : orient === 'PORTRAIT' ? 'Portrait' : 'Landscape'}
              </button>
            ))}
          </div>
          {settings.pageSize === 'AUTO' && settings.orientation === 'AUTO' && (
            <p className="text-[10px] text-white/30 font-sans mt-1">
              * Matches orientation of each source image individually.
            </p>
          )}
        </div>
      </div>

      {/* Advanced Layout & Fit Settings */}
      <div className="p-4 space-y-4">
        {/* Scaling Mode */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-indigo-400" /> Scaling & Placement
          </label>
          <div className="grid grid-cols-3 gap-1 p-0.5 bg-white/5 rounded-xl border border-white/10">
            {(['FIT', 'FILL', 'ORIGINAL'] as ScalingMode[]).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => updateSetting('scaling', mode)}
                className={`py-1.5 rounded-lg text-[10px] font-medium font-sans text-center transition-all ${
                  settings.scaling === mode
                    ? 'bg-indigo-650 shadow-md text-white font-semibold'
                    : 'text-white/40 hover:text-white/80'
                }`}
              >
                {mode === 'FIT' ? 'Fit Page' : mode === 'FILL' ? 'Stretch Fill' : 'Original Size'}
              </button>
            ))}
          </div>
          <p className="text-[10px] text-white/30 font-sans mt-1">
            {settings.scaling === 'FIT' && 'Image aspect ratio is preserved to fit safely inside margins.'}
            {settings.scaling === 'FILL' && 'Image stretches to fully fill the page boundaries without white gaps.'}
            {settings.scaling === 'ORIGINAL' && 'Retains original dimension, scales down only if too large.'}
          </p>
        </div>

        {/* Margins Selection */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <AlignJustify className="w-3.5 h-3.5 text-indigo-400" /> Margins
          </label>
          <div className="grid grid-cols-5 gap-1 p-0.5 bg-white/5 rounded-xl border border-white/10 mb-1.5">
            {(['NONE', 'THIN', 'STANDARD', 'THICK', 'CUSTOM'] as MarginPreset[]).map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => updateSetting('marginPreset', preset)}
                className={`py-1 rounded-lg text-[10px] font-medium font-sans text-center transition-all ${
                  settings.marginPreset === preset
                    ? 'bg-indigo-650 shadow-md text-white font-semibold'
                    : 'text-white/40 hover:text-white/80'
                }`}
              >
                {preset === 'NONE' ? 'None' : preset === 'THIN' ? 'Thin' : preset === 'STANDARD' ? 'Std' : preset === 'THICK' ? 'Thick' : 'Custom'}
              </button>
            ))}
          </div>

          {settings.marginPreset === 'CUSTOM' ? (
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-white/40 font-mono">Margin value:</span>
                <span className="text-[11px] text-indigo-400 font-mono font-semibold">{settings.customMargin} mm</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={settings.customMargin}
                onChange={(e) => updateSetting('customMargin', parseInt(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>
          ) : (
            <div className="flex justify-between items-center text-[10px] text-white/30 font-mono">
              <span>Selected Margin:</span>
              <span className="text-white/70">
                {settings.marginPreset === 'NONE' && '0 mm'}
                {settings.marginPreset === 'THIN' && '5 mm'}
                {settings.marginPreset === 'STANDARD' && '10 mm'}
                {settings.marginPreset === 'THICK' && '20 mm'}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Background and Sizing Optimizations */}
      <div className="p-4 space-y-4">
        {/* Background color selection */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-indigo-400" /> Paper Background
          </label>
          <div className="flex items-center gap-2 flex-wrap">
            {bgColorsPreset.map((bg) => (
              <button
                key={bg.name}
                type="button"
                title={bg.name}
                onClick={() => updateSetting('backgroundColor', bg.value)}
                className={`w-6 h-6 rounded-full border cursor-pointer flex items-center justify-center transition-all ${bg.class} ${
                  settings.backgroundColor === bg.value 
                    ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-[#0c0c14] scale-110 shadow-lg' 
                    : 'hover:scale-105'
                }`}
              >
                {settings.backgroundColor === bg.value && (
                  <div className={`w-1.5 h-1.5 rounded-full ${bg.value === '#ffffff' || bg.value === '#fafaf9' ? 'bg-slate-800' : 'bg-white'}`} />
                )}
              </button>
            ))}

            {/* Custom Background Input */}
            <div className="relative flex items-center ml-auto bg-white/5 border border-white/10 p-1 px-1.5 rounded-lg">
              <input
                type="color"
                value={settings.backgroundColor}
                onChange={(e) => updateSetting('backgroundColor', e.target.value)}
                className="w-6 h-5 p-0 border-0 cursor-pointer rounded bg-transparent"
                title="Pick customized color"
              />
              <span className="text-[10px] font-mono text-white/60 ml-1.5 uppercase select-none">
                {settings.backgroundColor}
              </span>
            </div>
          </div>
        </div>

        {/* Quality / Compression Slider */}
        <div>
          <div className="flex justify-between mb-1">
            <label className="text-xs font-semibold text-white/70 font-sans flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-indigo-400" /> Export Quality
            </label>
            <span className="text-[11px] font-mono font-semibold text-indigo-400">
              {Math.round(settings.imageQuality * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={settings.imageQuality}
            onChange={(e) => updateSetting('imageQuality', parseFloat(e.target.value))}
            className="w-full accent-indigo-500 cursor-pointer"
          />
          <div className="flex justify-between text-[9px] text-white/30 font-sans mt-0.5">
            <span>Small File Size</span>
            <span>Balanced</span>
            <span>Maximum Res</span>
          </div>
        </div>
      </div>

      {/* Headers and Page Number Indexing */}
      <div className="p-4 space-y-4">
        {/* Custom Header Text */}
        <div>
          <label className="block text-xs font-semibold text-white/70 mb-1.5 font-sans flex items-center gap-1.5">
            <AlignCenter className="w-3.5 h-3.5 text-indigo-400" /> Header Note
          </label>
          <input
            type="text"
            value={settings.customHeader}
            onChange={(e) => updateSetting('customHeader', e.target.value)}
            placeholder="e.g. Scanning Attachment 2026"
            className="w-full text-xs font-sans border border-white/10 rounded-xl px-3 py-2.5 bg-white/5 hover:bg-white/10 hover:border-white/20 focus:bg-white/10 focus:border-indigo-500 focus:outline-hidden transition-all text-white placeholder-white/30"
          />
          <p className="text-[9px] text-white/30 font-sans mt-1">
            * Header only displays when margins are greater than 5mm to safeguard image overlap.
          </p>
        </div>

        {/* Page numbering switch */}
        <div className="flex items-center justify-between py-1">
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-semibold text-white/70 font-sans flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-indigo-400" /> Page Numbering
            </span>
            <span className="text-[10px] text-white/30 font-sans">
              Print numeric tracker in footers
            </span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer select-none">
            <input
              type="checkbox"
              checked={settings.showPageNumbers}
              onChange={(e) => updateSetting('showPageNumbers', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-white/10 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-white/20 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600" />
          </label>
        </div>

        {/* Alignment */}
        {settings.showPageNumbers && (
          <div>
            <label className="block text-[10px] font-semibold text-white/50 mb-1 font-sans">
              Placement Alignment
            </label>
            <div className="grid grid-cols-3 gap-1 p-0.5 bg-white/5 rounded-xl border border-white/10">
              {(['left', 'center', 'right'] as const).map((pos) => (
                <button
                  key={pos}
                  type="button"
                  onClick={() => updateSetting('pageNumberPosition', pos)}
                  className={`py-1 rounded-lg text-[10px] capitalize font-medium font-sans text-center transition-all ${
                    settings.pageNumberPosition === pos
                      ? 'bg-indigo-650 shadow-md text-white font-semibold'
                      : 'text-white/40 hover:text-white/80'
                  }`}
                >
                  {pos}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* PDF Meta indexing fields */}
      <div className="p-4 space-y-3">
        <h3 className="text-xs font-semibold text-white font-sans flex items-center gap-1 mb-1">
          <Info className="w-3.5 h-3.5 text-white/40" /> Searchable Document Metadata
        </h3>

        {/* Author */}
        <div>
          <label className="text-[10px] font-semibold text-white/50 block mb-1 font-sans flex items-center gap-1">
            <User className="w-3 h-3 text-indigo-400" /> Author / Creator
          </label>
          <input
            type="text"
            value={settings.author}
            onChange={(e) => updateSetting('author', e.target.value)}
            placeholder="e.g. John Doe / Scanning App"
            className="w-full text-[11px] font-sans border border-white/10 rounded-xl px-3 py-2 bg-white/5 hover:bg-white/10 hover:border-white/20 focus:bg-white/10 focus:border-indigo-500 focus:outline-hidden text-white placeholder-white/20"
          />
        </div>

        {/* Title */}
        <div>
          <label className="text-[10px] font-semibold text-white/50 block mb-1 font-sans">
            Document Title
          </label>
          <input
            type="text"
            value={settings.title}
            onChange={(e) => updateSetting('title', e.target.value)}
            placeholder="e.g. Tax Receipts May 2026"
            className="w-full text-[11px] font-sans border border-white/10 rounded-xl px-3 py-2 bg-white/5 hover:bg-white/10 hover:border-white/20 focus:bg-white/10 focus:border-indigo-500 focus:outline-hidden text-white placeholder-white/20"
          />
        </div>
      </div>
    </div>
  );
}
