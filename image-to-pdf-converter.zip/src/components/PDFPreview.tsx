/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UploadedImage, PdfSettings, PAGE_DIMENSIONS_MM, MARGINS_MM } from '../types';
import { Eye, Smartphone, BookOpen, AlertCircle } from 'lucide-react';

interface PDFPreviewProps {
  images: UploadedImage[];
  settings: PdfSettings;
}

export default function PDFPreview({ images, settings }: PDFPreviewProps) {
  if (images.length === 0) {
    return (
      <div className="bg-white/3 border border-white/10 rounded-3xl p-8 text-center flex flex-col items-center justify-center text-white/30 select-none">
        <Eye className="w-8 h-8 text-white/20 mb-2 stroke-[1.5]" />
        <h3 className="text-xs font-semibold text-white/80 font-sans uppercase tracking-wider">
          Layout Sheet Simulator
        </h3>
        <p className="text-xs text-white/40 mt-1 max-w-xs leading-relaxed font-sans">
          Preview sheet margins, page orientations, background configurations, and header note alignments.
        </p>
      </div>
    );
  }

  const marginVal = settings.marginPreset === 'CUSTOM' ? settings.customMargin : MARGINS_MM[settings.marginPreset];

  return (
    <div className="space-y-4">
      {/* Title */}
      <div className="flex items-center gap-2 bg-white/5 border border-white/10 p-3 rounded-2xl select-none">
        <Eye className="w-4 h-4 text-indigo-400 animate-pulse" />
        <h3 className="text-xs font-bold text-white font-sans uppercase tracking-wider">
          Real-time Sheet Simulator
        </h3>
      </div>

      {/* Simulator Sheet Stream */}
      <div className="space-y-6 max-h-[620px] overflow-y-auto p-4 bg-[#080811]/60 rounded-3xl border border-white/10 shadow-inner">
        {images.map((image, idx) => {
          const rotationAngle = image.rotation || 0;
          const isImageLandscape = image.aspectRatio > 1;

          // Determine page aspect ratio
          let pageW = 210;
          let pageH = 297;

          if (settings.pageSize === 'AUTO') {
            pageW = image.width * 0.264583;
            pageH = image.height * 0.264583;

            // Apply orientation settings on Auto size
            if (settings.orientation === 'PORTRAIT' && pageW > pageH) {
              const temp = pageW;
              pageW = pageH;
              pageH = temp;
            } else if (settings.orientation === 'LANDSCAPE' && pageH > pageW) {
              const temp = pageW;
              pageW = pageH;
              pageH = temp;
            }
          } else {
            const dims = PAGE_DIMENSIONS_MM[settings.pageSize];
            const isLandscape =
              settings.orientation === 'LANDSCAPE' ||
              (settings.orientation === 'AUTO' && isImageLandscape);
            pageW = isLandscape ? dims.height : dims.width;
            pageH = isLandscape ? dims.width : dims.height;
          }

          // Convert into CSS percentage aspect ratio
          const pageAspectRatio = pageW / pageH;

          // Calculate margin bounds in relative terms
          const horizontalMarginPercentage = (marginVal / pageW) * 100;
          const verticalMarginPercentage = (marginVal / pageH) * 100;

          // Scaling Style mappings inside printable bounds
          let imageStyle: React.CSSProperties = {};
          if (settings.scaling === 'FIT') {
            imageStyle = {
              width: '100%',
              height: '100%',
              objectFit: 'contain',
              // Apply rotation
              transform: `rotate(${rotationAngle}deg)`,
            };
          } else if (settings.scaling === 'FILL') {
            imageStyle = {
              width: '100%',
              height: '100%',
              objectFit: 'fill',
              // Apply rotation
              transform: `rotate(${rotationAngle}deg)`,
            };
          } else {
            // ORIGINAL Size centering, limit max size to printable box
            imageStyle = {
              maxWidth: '100%',
              maxHeight: '100%',
              objectFit: 'contain',
              margin: 'auto',
              // Apply rotation
              transform: `rotate(${rotationAngle}deg)`,
            };
          }

          return (
            <div key={image.id} className="flex flex-col items-center">
              {/* Page Indicator */}
              <div className="flex items-center justify-between w-full max-w-md px-1.5 mb-1.5 text-[10px] text-white/40 font-mono">
                <span>PAGE {idx + 1} ({settings.pageSize})</span>
                <span className="uppercase text-white/50">
                  {pageW > pageH ? 'LANDSCAPE' : 'PORTRAIT'} • {Math.round(pageW)}x{Math.round(pageH)}MM
                </span>
              </div>

              {/* Physical Sheet Container */}
              <div
                className="w-full max-w-md relative shadow-2xl rounded-lg border border-white/15 transform transition-all duration-300"
                style={{
                  aspectRatio: pageAspectRatio,
                  backgroundColor: settings.backgroundColor,
                }}
              >
                {/* Simulated Header */}
                {settings.customHeader && marginVal > 5 && (
                  <div
                    className="absolute top-[2.5%] left-0 right-0 overflow-hidden px-4 text-slate-550 border-b border-slate-200/50 flex justify-between select-none"
                    style={{
                      fontSize: 'min(1.8vw, 10px)',
                      left: `${horizontalMarginPercentage}%`,
                      right: `${horizontalMarginPercentage}%`,
                    }}
                  >
                    <span className="truncate">{settings.customHeader}</span>
                  </div>
                )}

                {/* Printable Boundary Box representing margin lines */}
                <div
                  className="absolute inset-0 transition-all duration-300 flex items-center justify-center pointer-events-none"
                  style={{
                    top: `${verticalMarginPercentage}%`,
                    bottom: `${verticalMarginPercentage}%`,
                    left: `${horizontalMarginPercentage}%`,
                    right: `${horizontalMarginPercentage}%`,
                    border: marginVal > 0 ? '1px dashed rgba(99, 102, 241, 0.4)' : 'none',
                  }}
                >
                  {/* Embedded source image */}
                  <div className="w-full h-full flex items-center justify-center p-0.5 overflow-hidden">
                    <img
                      src={image.src}
                      alt={image.name}
                      referrerPolicy="no-referrer"
                      style={imageStyle}
                      className="transition-transform duration-300 pointer-events-none"
                    />
                  </div>
                </div>

                {/* Simulated Footer */}
                {settings.showPageNumbers && (marginVal > 4 || settings.pageSize === 'AUTO') && (
                  <div
                    className={`absolute bottom-[2%] text-slate-400 select-none ${
                      settings.pageNumberPosition === 'left'
                        ? 'left-[4%]'
                        : settings.pageNumberPosition === 'right'
                        ? 'right-[4%]'
                        : 'left-1/2 -translate-x-1/2'
                    }`}
                    style={{
                      fontSize: 'min(1.7vw, 9px)',
                    }}
                  >
                    Page {idx + 1} of {images.length}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {marginVal === 0 && (settings.showPageNumbers || settings.customHeader) && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-[10px] text-amber-300 font-sans leading-relaxed">
            <strong>Full Bleed Warning:</strong> Margins are configured to <span className="font-mono">NONE</span>. Your Header notes and footer trackers will not be drawn on pages to prevent overlap.
          </p>
        </div>
      )}
    </div>
  );
}
