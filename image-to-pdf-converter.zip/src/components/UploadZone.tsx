/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Upload, Image as ImageIcon, Sparkles } from 'lucide-react';
import { UploadedImage } from '../types';

interface UploadZoneProps {
  onImagesAdded: (newImages: UploadedImage[]) => void;
}

export default function UploadZone({ onImagesAdded }: UploadZoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessing(true);

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    const newAddedImages: UploadedImage[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!validTypes.includes(file.type)) continue;

      const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      const src = URL.createObjectURL(file);

      // Measure dimensions
      const dims = await new Promise<{ width: number; height: number }>((resolve) => {
        const img = new Image();
        img.onload = () => {
          resolve({ width: img.naturalWidth, height: img.naturalHeight });
        };
        img.onerror = () => {
          resolve({ width: 800, height: 600 });
        };
        img.src = src;
      });

      newAddedImages.push({
        id,
        name: file.name,
        file,
        src,
        size: file.size,
        width: dims.width,
        height: dims.height,
        aspectRatio: dims.width / dims.height,
        type: file.type,
      });
    }

    if (newAddedImages.length > 0) {
      onImagesAdded(newAddedImages);
    }
    setIsProcessing(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(true);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const triggerSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div
      id="upload-drag-zone"
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      onClick={triggerSelect}
      className={`relative border-2 border-dashed rounded-3xl p-10 text-center cursor-pointer transition-all duration-300 flex flex-col items-center justify-center min-h-[220px] ${
        isDragActive
          ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
          : 'border-white/10 bg-white/3 hover:border-white/20 hover:bg-white/5'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/jpeg,image/png,image/webp,image/gif"
        onChange={onFileChange}
        className="hidden"
      />

      <div className={`p-4 rounded-full bg-white/5 border border-white/10 transition-colors duration-300 ${
        isDragActive ? 'bg-indigo-500/20 border-indigo-400/40' : ''
      }`}>
        {isProcessing ? (
          <div className="absolute inset-0 flex items-center justify-center bg-[#0c0c14]/85 backdrop-blur-md rounded-3xl z-20">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm font-medium text-white/80 font-sans">Processing layout parameters...</p>
            </div>
          </div>
        ) : (
          <Upload className={`w-8 h-8 ${isDragActive ? 'text-indigo-400 animate-bounce' : 'text-slate-400'}`} />
        )}
      </div>

      <div className="mt-4 max-w-sm">
        <h3 className="text-base font-semibold text-white font-sans tracking-tight">
          Drag and drop images here
        </h3>
        <p className="text-xs text-white/40 font-sans mt-1">
          Supports JPEG, PNG, WEBP and GIF format up to 25MB.
        </p>
      </div>

      <div className="mt-5 inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 hover:scale-105 active:scale-95 text-white transition-all text-xs font-semibold rounded-xl shadow-lg shadow-indigo-600/20">
        <ImageIcon className="w-3.5 h-3.5" />
        Choose Local Images
      </div>
    </div>
  );
}
