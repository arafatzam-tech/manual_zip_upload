/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UploadedImage } from '../types';
import { 
  ArrowUp, ArrowDown, Trash2, RotateCw, Image, SortAsc, SortDesc, Ban, 
  ChevronDown, ChevronUp, FileImage
} from 'lucide-react';

interface PDFPageListProps {
  images: UploadedImage[];
  onMoveUp: (index: number) => void;
  onMoveDown: (index: number) => void;
  onRemove: (id: string) => void;
  onRotate: (id: string) => void;
  onClearAll: () => void;
  onSort: (type: 'name-asc' | 'name-desc' | 'size-asc' | 'size-desc') => void;
}

export default function PDFPageList({
  images,
  onMoveUp,
  onMoveDown,
  onRemove,
  onRotate,
  onClearAll,
  onSort,
}: PDFPageListProps) {
  
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  if (images.length === 0) {
    return (
      <div className="bg-white/3 border border-white/10 rounded-3xl p-10 text-center flex flex-col items-center justify-center text-white/40">
        <Image className="w-10 h-10 text-white/20 stroke-[1.5]" />
        <p className="mt-3 text-sm font-semibold font-sans text-white/80">No images ready for conversion</p>
        <p className="text-xs text-white/40 mt-1">Upload images above to build your document structure.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Title & Global controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 p-3 rounded-2xl border border-white/10 shadow-lg select-none">
        <div className="flex items-center gap-2">
          <FileImage className="w-4 h-4 text-indigo-400" />
          <h2 className="text-xs font-bold text-white font-sans uppercase tracking-wider">
            Document Pages ({images.length})
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Sorting controls */}
          <div className="relative group">
            <button className="flex items-center gap-1.5 text-xs text-white/80 font-medium px-3 py-1.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all">
              <SortAsc className="w-3.5 h-3.5 text-white/60" />
              <span>Sort</span>
            </button>
            <div className="absolute right-0 top-full mt-1.5 w-44 bg-[#0a0a14]/95 backdrop-blur-xl border border-white/15 rounded-xl shadow-xl py-1 hidden group-hover:block z-35">
              <button
                onClick={() => onSort('name-asc')}
                className="w-full text-left px-3 py-1.5 text-xs text-white hover:bg-white/10 font-sans flex items-center gap-2 transition-colors cursor-pointer"
              >
                <span>Filename A-Z</span>
              </button>
              <button
                onClick={() => onSort('name-desc')}
                className="w-full text-left px-3 py-1.5 text-xs text-white hover:bg-white/10 font-sans flex items-center gap-2 transition-colors cursor-pointer"
              >
                <span>Filename Z-A</span>
              </button>
              <hr className="border-white/5 my-1" />
              <button
                onClick={() => onSort('size-asc')}
                className="w-full text-left px-3 py-1.5 text-xs text-white hover:bg-white/10 font-sans transition-colors cursor-pointer"
              >
                Size: Small to Large
              </button>
              <button
                onClick={() => onSort('size-desc')}
                className="w-full text-left px-3 py-1.5 text-xs text-white hover:bg-white/10 font-sans transition-colors cursor-pointer"
              >
                Size: Large to Small
              </button>
            </div>
          </div>

          <button
            onClick={onClearAll}
            className="flex items-center gap-1 text-xs text-rose-300 font-medium px-3 py-1.5 bg-rose-500/10 border border-rose-500/25 rounded-xl hover:bg-rose-500/20 transition-all cursor-pointer"
          >
            <Ban className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        </div>
      </div>

      {/* Pages Container Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {images.map((image, idx) => {
          const rotationAngle = image.rotation || 0;
          return (
            <div
              key={image.id}
              className="backdrop-blur-md bg-white/5 border border-white/10 rounded-3xl p-3 shadow-xl hover:border-white/20 transition-all relative group flex flex-col justify-between"
            >
              {/* Badge for page ordinal index */}
              <div className="absolute top-2.5 left-2.5 z-10 bg-indigo-600 border border-indigo-400 text-white font-mono font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                {idx + 1}
              </div>

              {/* Main row: Thumbnail on left, meta on right */}
              <div className="flex gap-4">
                {/* Thumbnail element */}
                <div className="w-24 h-24 bg-white/3 rounded-2xl border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                  <div 
                    className="w-full h-full p-1.5 flex items-center justify-center transition-transform duration-300"
                    style={{ transform: `rotate(${rotationAngle}deg)` }}
                  >
                    <img
                      src={image.src}
                      alt={image.name}
                      referrerPolicy="no-referrer"
                      className="max-w-full max-h-full object-contain rounded-md"
                    />
                  </div>
                </div>

                {/* Meta descriptor block */}
                <div className="flex-1 min-w-0 flex flex-col justify-between text-white">
                  <div>
                    <h3
                      title={image.name}
                      className="text-xs font-semibold text-white truncate font-sans pr-14"
                    >
                      {image.name}
                    </h3>
                    <div className="space-y-0.5 mt-1">
                      <p className="text-[10px] text-white/40 font-sans flex items-center gap-1">
                        <span>Size:</span>
                        <span className="font-mono text-white/70 font-medium">
                          {formatBytes(image.size)}
                        </span>
                      </p>
                      <p className="text-[10px] text-white/40 font-sans flex items-center gap-1">
                        <span>Original Res:</span>
                        <span className="font-mono text-white/70 font-medium">
                          {image.width} × {image.height} px
                        </span>
                      </p>
                      <p className="text-[10px] text-white/40 font-sans flex items-center gap-1">
                        <span>Orientation:</span>
                        <span className="font-mono text-white/70 font-medium capitalize">
                          {image.aspectRatio > 1 ? 'Landscape' : 'Portrait'}
                        </span>
                      </p>
                    </div>
                  </div>

                  {/* Individual actions block */}
                  <div className="flex items-center gap-1.5 mt-1.5">
                    {/* Rotate */}
                    <button
                      type="button"
                      title="Rotate Page (90° Clockwise)"
                      onClick={() => onRotate(image.id)}
                      className="p-1 px-2 border border-white/10 rounded-lg bg-white/5 hover:bg-white/10 hover:text-indigo-300 text-white/70 transition-all text-[10px] flex items-center gap-1 font-medium cursor-pointer"
                    >
                      <RotateCw className="w-3 h-3 text-indigo-400" />
                      <span>{rotationAngle > 0 ? `${rotationAngle}°` : 'Rotate'}</span>
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      title="Delete Page"
                      onClick={() => onRemove(image.id)}
                      className="p-1 px-2 border border-rose-500/20 rounded-lg bg-rose-500/10 hover:bg-rose-500/25 text-rose-300 transition-all text-[10px] ml-auto cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Movement controls footer */}
              <div className="mt-3 border-t border-white/5 pt-2 flex items-center justify-between">
                <span className="text-[10px] text-white/30 font-mono font-medium">
                  ORDER POSITION
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => onMoveUp(idx)}
                    className="p-1 rounded-lg border border-white/10 bg-white/5 text-white/70 hover:bg-white/10 disabled:opacity-20 transition-all cursor-pointer"
                    title="Move Page Up"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === images.length - 1}
                    onClick={() => onMoveDown(idx)}
                    className="p-1 rounded-lg border border-white/10 bg-white/5 text-white/70 hover:bg-white/10 disabled:opacity-20 transition-all cursor-pointer"
                    title="Move Page Down"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
